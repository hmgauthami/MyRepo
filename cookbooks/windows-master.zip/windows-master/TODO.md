TODO
----
* package preseeding/`response_file` support
* package installation location via a `target_dir` attribute.
* [COOK-666] `windows_package` should support CoApp packages
* WindowsRebootHandler/`windows_reboot` LWRP should support kicking off subsequent chef run on reboot.
